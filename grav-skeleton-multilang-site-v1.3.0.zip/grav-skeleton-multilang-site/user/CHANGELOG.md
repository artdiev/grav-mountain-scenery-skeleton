# v1.3.0
## 12/11/2015

1. [](#improved)
	* Improved German

# v1.2.0
## 09/11/2015

1. [](#new)
    * Added Norwgian
1. [](#improved)
	* Improved French

# v1.1.1
## 09/08/2015

1. [](#new)
    * Added Polish

# v1.1.0
## 07/19/2015

1. [](#new)
    * Added German
    * Added Spanish
    * Added Italian
    * Added French
    * Added Dutch

# v1.0.0
## 07/14/2015

1. [](#new)
    * ChangeLog started...
