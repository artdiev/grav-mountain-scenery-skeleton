---
title: Informazioni
class: home
profile: true
---

Questa è una pagina standard. Potrebbe essere una **pagina di informazioni** o una pagina di riepilogo dove descrivere il proprio talento che si intende offrire al mondo dello sviluppo web.

Questa pagina ha nell'intestazione l'attributo `profile: true` che consente di visualizzare nella parte superiore della pagina le informazioni biografiche. 
