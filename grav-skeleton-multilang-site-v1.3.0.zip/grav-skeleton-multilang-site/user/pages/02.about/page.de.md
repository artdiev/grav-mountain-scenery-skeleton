---
title: Über mich
class: home
profile: true
---

Das ist eine Standard-Seite. Dies könnte eine **Über mich Seite** oder eine Seite mit verschiedenen Inhalten sein, das deine ganze Leistungen und Angebote zeigt, die du anbieten möchtest. 

Diese Seite hat im Header das `profile: true` das bewirkt, dass deine persönlichen Informationen oben auf der Seite angezeigt werden.
