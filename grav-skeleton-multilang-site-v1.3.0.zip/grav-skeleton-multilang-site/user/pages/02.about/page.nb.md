---
title: Om
class: home
profile: true
---

Dette er en standardside. Den kan være en **om**-side eller en oppsummeringsside som viser dine mange evner og talenter som du ønsker å bringe til verdenen av webutvikling.

Denne siden har meta-egenskapen `profile: true` som gjør at bio-informasjon vises på toppen av siden.