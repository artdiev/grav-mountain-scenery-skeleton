---
title: Over
class: home
profile: true
---

Dit is een standaard pagina. Het zou een **Over mezelf** of overzichtspagina kunnen zijn die uw vele gaves en talenten beschrijft die u wenst in te zetten in de wereld van de web ontwikkeling.

Deze pagina heeft het hoofdingsattribuut (header attribute) `profile: true`. Dit zorgt ervoor dat de bio informatie bovenaan de pagina wordt getoond.
