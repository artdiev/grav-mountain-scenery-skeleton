---
title: À propos
class: home
profile: true
---

Ceci est une page normale. Ça pourrait être une page **« À propos »** ou une page décrivant les nombreux talents et dons que vous désirez mettre à disposition du monde du développement web.

Cette page a un attribut header `profile: true` qui affichera les informations de votre bio dans son en-tête.
