---
title: O mnie
class: home
profile: true
---

To jest standardowa strona. Może być traktowana jako **wizytówka** lub podsumowanie twoich talentów i zdolności, które chcesz wnieść do świata tworzenia stron internetowych.

Strona posiada atrybut nagłówka `profile: true` który sprawia że krótka notka jest wyświetlana na górze strony.