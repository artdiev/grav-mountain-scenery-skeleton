---
title: Sobre Nosotros
class: home
profile: true
---

Esto es una página estándar. Puede ser usada como **página sobre nosotros** o una página resumiendo los talentos que quieras traer al mundo del desarrollo web.

Esta página tiene un atributo en el header `profile: true` eso hace que la información biográfica sea mostrada en la parte superior de la página.
