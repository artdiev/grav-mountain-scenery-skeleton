---
title: Welcome to Grav!
date: 16:00 10-07-2015
headline: Get ready to fall in love :)
taxonomy:
    category: blog
    tag: [grav]
---

You'll find this post in your `user/pages/01.blog/welcome-to-grav` folder - edit this post and reload the browser to see your changes.

To add new posts, simply add a folder in the `user/pages/01.blog/` folder and give it a unique slug for folder name. Then copy this `post.md` file into it and edit.

---

[Grav][grav] supports [markdown](https://en.wikipedia.org/wiki/Markdown) so you can do things like this:

## Basic formatting

Paragraphs can be written like so. A paragraph is the basic block of Markdown. A paragraph is what text will turn into when there is no reason it should become anything else.

Paragraphs must be separated by a blank line. Basic formatting of *italics* and **bold** is supported. This *can be **nested** like* so.

Check out the [Grav docs][grav-docs] for more info on how to get the most out of Grav. File all bugs/feature requests at [Grav's GitHub repo][grav-gh].

[grav]: http://getgrav.org
[grav-docs]: http://learn.getgrav.org
[grav-gh]: https://github.com/getgrav/grav

