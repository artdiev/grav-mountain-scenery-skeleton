---
title: Willkommen zu Grav!
date: 16:00 10-07-2015
headline: Probiere es aus und liebe es :)
taxonomy:
    category: blog
    tag: [grav]
---

Diesen Beitrag findest du in dem Verzeichnis `user/pages/01.blog/welcome-to-grav`  - bearbeite diesen Artikel, lade Sie die Seite neu und schon kannst du die Änderungen sehen.

Wenn du einen neuen Artikel erstellen möchtest – lege einen neuen Ordner in dem Verzeichnis `user/pages/01.blog/` an. Gib dem Ordner einen einzigartigen Namen. Dann kopiere die Datei `post.md` in den Ordner und bearbeite Sie.

---

Grav unterstützt [markdown](https://en.wikipedia.org/wiki/Markdown) somit kannst du folgende Funktionen nutzen:

## Standard Formatierung

Absätze können einfach so geschrieben werden. Ein Absatz ist der Standard in Markdown. Ein Absatz wird immer dann ausgegeben wenn er nicht in einer anderen.

Absätze müssen durch eine Leerzeile getrennt werden. Standard Formatierungen wie *kursiv* und **fett** werden unterstützt. Dies kann auch so verschachtelt *can be **nested** like* so.

Schau Dir [Grav docs][grav-docs] an und wie du das meiste aus Grav heraus holen kannst. Dateien mit Fehlern oder neuen Funktionen bitte an [Grav's GitHub repo][grav-gh].

[grav]:    http://jekyllrb.com
[grav-docs]: http://learn.getgrav.org
[grav-gh]: https://github.com/getgrav/grav

