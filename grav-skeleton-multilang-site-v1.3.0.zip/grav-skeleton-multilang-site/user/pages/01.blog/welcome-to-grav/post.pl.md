---
title: Witaj w świecie Grav!
date: 16:00 10-07-2015
headline: Przygotuj się na miłość od pierwszej instalacji :)
taxonomy:
    category: blog
    tag: [grav]
---

Znajdziesz ten wpis w folderze `user/pages/01.blog/welcome-to-grav`, wyedytuj ten plik i odśwież przeglądarkę aby zobaczyć zmiany.

Aby dodać nowy wpis, dodaj folder do `user/pages/01.blog/` oraz nadaj mu unikalą nazwę (będzie służyła jako łącze, tzw "slug"). Potem skopiuj ten plik `post.md` do utworzonego wcześniej folderu i wyedytuj go.

---

[Grav][grav] posiada wsparcie dla [markdown](https://en.wikipedia.org/wiki/Markdown), więc możesz stosować:

## Podstawowe formatowanie

Paragrafy w Markdown, to w wielkim skrócie, to co piszesz. Są podstawowym blokiem w Markdown. Tekst będzie paragrafem w momencie, gdy nie zostaną do niego przypisane żadne inne atrybuty.

Każdy paragaf musi być oddzielony nową pustą linijką. Podstawowe wsparcie dla formatowania *pochylonego* oraz **pogrubionego** także jest zapewnione. Formatowania *mogą być **zagnieżdżone**, tak jak to.*

Odwiedź [Dokumentację][grav-docs] aby poznać dokładnie Grav-a i dowiedzieć się więcej o jego unikalnych właściwościach. Zgłoś błędy/propozycje ulepszeń do [Repozytorium Grav-a na GitHub][grav-gh].

[grav]: http://getgrav.org
[grav-docs]: http://learn.getgrav.org
[grav-gh]: https://github.com/getgrav/grav

