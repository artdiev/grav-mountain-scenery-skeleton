---
title: Welkom bij Grav!
date: 16:00 10-07-2015
headline: Get ready to fall in love :)
taxonomy:
    category: blog
    tag: [grav]
---

U zal deze post in uw `user/pages/01.blog/welcome-to-grav` map vinden - Wijzig deze post en herlaad de browser om uw veranderingen te zien.

Om nieuwe posts toe te voegen, voegt u slechts een nieuwe map toe in de map `user/pages/01.blog/` en geef het een uniek `slug` hoofdingsattribuut voor de map's naam. Kopieer vervolgens deze `post.md` in de nieuwe map en wijzig de inhoud.

---

[Grav][grav] ondersteunt [markdown](https://en.wikipedia.org/wiki/Markdown). U kan dus zaken doen zoals:

## Basis opmaak

Paragrafen worden opgemaakt zoals deze tekst. Een paragraaf is een basis element van Markdown. Elke tekst zal als een paragraaf worden opgemaakt, indien er geen reden is het op te maken tot iets anders.

Paragrafen moeten gescheiden worden door een lege lijn. Basis opmaken zoals *cursief* en **vet** worden ondersteund. Dit kan, *zoals **hier** ook genest* worden.

Sla er de [Grav documentatie][grav-docs] op na om het beste uit Grav te halen. Dien alle aanvragen van fouten/verbeteringen in via [Grav's GitHub repository][grav-gh] a.u.b.

[grav]: http://getgrav.org
[grav-docs]: http://learn.getgrav.org
[grav-gh]: https://github.com/getgrav/grav

