---
title: Benvenuti in Grav!
date: 16:00 10-07-2015
headline: Tenersi pronti ad innamorarsi :)
taxonomy:
    category: blog
    tag: [grav]
---

Questo messaggio si trova nella cartella `user/pages/01.blog/welcome-to-grav` - modificare il messaggio e ricaricare il browser per visualizzare le modifiche.

Per aggiungere nuovi messaggi, è sufficiente aggiungere una cartella in `user/pages/01.blog/` e nominarla con un slug unico. Quindi copiarci dentro il file `post.md` e modificarlo.

---

[Grav][grav] supporta [markdown](https://en.wikipedia.org/wiki/Markdown) per poter fare quanto segue:

## Formattazione di base

I paragrafi possono essere scritti in questo modo. Un paragrafo è il blocco di base di Markdown. Un paragrafo è ciò in cui il testo si trasformerà quando non vi è alcuna ragione per cui dovrebbe essere diverso.

I paragrafi devono essere separati da una riga vuota. La formattazione di base prevede il *corsivo* ed il *grassetto*. Ciò *può essere anche mediante **annidamento***.

Andare alla [Documentazione Grav][Grav-docs] per ulteriori informazioni su come ottenere il massimo da Grav. Tutti i file e le richieste di correzione errori/nuove funzionalità si trovano nel [Repository GitHub di Grav][Grav-gh].

[grav]: http://getgrav.org
[grav-docs]: http://learn.getgrav.org
[grav-gh]: https://github.com/getgrav/grav

