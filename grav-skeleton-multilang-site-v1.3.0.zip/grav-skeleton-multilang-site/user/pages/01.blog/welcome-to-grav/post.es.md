---
title: Bienvenido a Grav!
date: 16:00 10-07-2015
headline: Prepárate para enamorarte :)
taxonomy:
    category: blog
    tag: [grav]
---

Encontrarás este artículo en tu carpeta `user/pages/01.blog/welcome-to-grav` - edita este post y refresca el navegador para ver los cambios.

Para agregar un nuevo artículo, simplemente agrega una carpeta a la carpeta `user/pages/01.blog/` y asígnale un slug único para el nombre de la carpeta. Luego copia este archivo `post.md` y edítalo.

---

[Grav][grav] soporta [markdown](https://en.wikipedia.org/wiki/Markdown) así que puedes hacer cosas como estas:

## Formato Básico

Los párrafos pueden ser escritos de esta manera. Un párrafo es el bloque básico de Markdown. Un párrafo es en lo que el texto se convertira cuando no haya otra razón para convertirse en otra cosa.

Los párrafos deben ser separados por una línea en blanco. El formato básico para *cursivas* y **negrita** son soportados. Esto *puede ser **anidado** de esta manera*.

Revisa la [documentación de Grav][grav-docs] para más información de como sacarle el jugo a Grav. Escríbenos con cualquier bug o solicitud de funcionalidad al [repositorio GitHub de Grav][grav-gh].

[grav]: http://getgrav.org
[grav-docs]: http://learn.getgrav.org
[grav-gh]: https://github.com/getgrav/grav

