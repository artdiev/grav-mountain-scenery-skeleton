---
title: Velkommen til Grav!
date: 16:00 10-07-2015
headline: Gjør deg klar til å bli forelsket :)
taxonomy:
    category: blog
    tag: [grav]
---

Du kan finne dette innlegget i `user/pages/01.blog/welcome-to-grav`-mappen din - rediger dette innlegget og oppdater nettleseren din for å se forandringene.

For å legge til nye innlegg, lag en mappe i `user/pages/01.blog/`-mappen og gi den en unik tittel som mappenavn. Kopier så denne `post.md`-filen inn i mappen og rediger den.

---

[Grav][grav] støtter [Markdown](https://en.wikipedia.org/wiki/Markdown) så du kan gjøre ting som dette:

## Enkel formatering

Paragrafer kan skrives slik. En paragraf er den grunnleggende blokken i Markdown. En paragraf er det tekst omgjøres til når det ikke er noe grunn til at den skal bli noe annet.

Paragrafer separeres med en blank linke. Enkel formatering som *kursiv* og **fet skrift** støttes og. Disse *kan også **brettes** slik*.

Sjekk ut [Grav-dokumentasjon][grav-docs] for mer informasjon om hvordan du kan få mest ut av Grav. Send inn feil/funksjonsforespørsler til [Grav's GitHub repo][grav-gh].

[grav]: http://getgrav.org
[grav-docs]: http://learn.getgrav.org
[grav-gh]: https://github.com/getgrav/grav

