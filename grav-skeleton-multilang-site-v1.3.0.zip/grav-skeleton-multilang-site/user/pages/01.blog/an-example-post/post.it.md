---
title: Un esempio di messaggio
date: 20:18 23-06-2015
headline: Riempito con contenuto di esempio
taxonomy:
    category: blog
    tag: [grav]
---

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

 > Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

 Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat

| Tabelle |         Sono         |  Eccezionali |
|---------|:--------------------:|-------------:|
| col 1 è | allineata a sinistra |        €1600 |
| col 2 è |        centrata      |          €12 |
| col 3 è |  allineata a destra  |           €1 |

Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius.
